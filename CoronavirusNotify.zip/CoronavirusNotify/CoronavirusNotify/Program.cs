﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.IO;
using System.Threading.Tasks;
using System.Media;
using System.Windows;
using System.Diagnostics;
using System.Threading;

namespace CoronavirusNotify
{
    class Program
    {
        static void Main(string[] args)
        {
            //System.Media.SoundPlayer player = new SoundPlayer(@"cases.wav");
            string[] lines;
            while (true)
            {
                IWebDriver driver = new ChromeDriver();
                driver.Url = "https://www.worldometers.info/coronavirus/#page-top";
                IWebElement infectedCountUnparsed = driver.FindElement(By.ClassName("maincounter-number"));
                Console.WriteLine(infectedCountUnparsed.Text);
                string infectedCount = infectedCountUnparsed.Text;
                Thread.Sleep(5000);
                driver.Url = "https://www.worldometers.info/coronavirus/coronavirus-death-toll/";
                IWebElement deathCountUnparsed = driver.FindElement(By.ClassName("maincounter-number"));
                string deathCount = deathCountUnparsed.Text.Substring(0, deathCountUnparsed.Text.LastIndexOf(" "));
                Console.WriteLine(deathCount);
                lines = System.IO.File.ReadAllLines(@"cases.txt");
                if (infectedCount != lines[0])
                {
                    Process proc = new Process();
                    proc.StartInfo.FileName = "cases.bat";
                    proc.StartInfo.CreateNoWindow = false;
                    proc.Start();
                }
                if(lines[1] != deathCount)
                {
                    Process proc = new Process();
                    proc.StartInfo.FileName = "deaths.bat";
                    proc.StartInfo.CreateNoWindow = false;
                    proc.Start();
                }
                System.IO.File.WriteAllLines(@"cases.txt", new string[] { infectedCount, deathCount});
                driver.Close();
                Thread.Sleep(10000);
            }
        }
    }
}
